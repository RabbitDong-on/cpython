.. _api.webapp2_extras.appengine.sessions_ndb:

Datastore sessions
==================
.. module:: webapp2_extras.appengine.sessions_ndb

This module requires you to add the ``ndb`` package to your app. See `NDB`_.

.. autoclass:: DatastoreSessionFactory
   :members: session_model


.. _NDB: http://code.google.com/p/appengine-ndb-experiment/
