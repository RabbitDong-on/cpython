.. _api.webapp2_extras.appengine.sessions_memcache:

Memcache sessions
=================
.. module:: webapp2_extras.appengine.sessions_memcache

.. autoclass:: MemcacheSessionFactory
