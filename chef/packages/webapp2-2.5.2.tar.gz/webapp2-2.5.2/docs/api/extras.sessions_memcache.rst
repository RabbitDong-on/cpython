Memcache sessions
=================
This page moved to :ref:`api.webapp2_extras.appengine.sessions_memcache`.
